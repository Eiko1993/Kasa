import routes from "./Components/Routes"
import "./Style/index.scss"

// charge les routes pour les différentes pages, ainsi que la page d'erreur
routes();
import routes from "./Components/Routes";

// charge les routes pour les différentes pages, ainsi que la page d'erreur
routes();
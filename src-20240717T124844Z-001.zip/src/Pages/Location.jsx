import { useState } from "react";
import { Link } from 'react-router-dom'
import PropTypes from 'prop-types'

function Location(){

}

export default Location;
